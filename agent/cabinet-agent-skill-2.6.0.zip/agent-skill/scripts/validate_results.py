#!/usr/bin/env python3
"""Cabinet protocol 3/2/1 validator. Standard-library only; uses installed, closed schemas.

Usage: validate_results.py --batch batch.zip [--results valuation-results.json]
Also supports legacy positional arguments: validate_results.py batch.zip results.json.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import math
import re
import sys
import zipfile
import unicodedata
import ipaddress
from fractions import Fraction
from decimal import Decimal, ROUND_HALF_UP, localcontext
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit, parse_qsl, urlencode, quote, unquote

ROOT = Path(__file__).resolve().parent.parent
REFERENCES = ROOT / 'references'
MAX_SAFE = 9007199254740991

class Invalid(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise Invalid(message)

def json_pairs(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, 'Duplicate JSON key: ' + key)
        obj[key] = value
    return obj

def number_json(value):
    require(math.isfinite(value), 'Nonfinite JSON number')
    if value == 0:
        return '0'
    if float(value).is_integer():
        require(abs(value) <= MAX_SAFE, 'Unsafe integer counter')
        return str(int(value))
    source = repr(value).lower()
    if 'e' not in source:
        return source
    mantissa, exponent = source.split('e')
    power = int(exponent)
    if 1e-6 <= abs(value) < 1e21:
        return format(Decimal(source), 'f')
    return mantissa.removesuffix('.0') + 'e' + ('+' if power >= 0 else '-') + str(abs(power))

def canonicalize(value, depth=0):
    require(depth <= 100, 'JSON nesting limit exceeded')
    if value is None:
        return 'null'
    if value is True:
        return 'true'
    if value is False:
        return 'false'
    if isinstance(value, str):
        try:
            value.encode('utf-8', 'strict')
        except UnicodeError as exc:
            raise Invalid('Invalid Unicode: lone surrogate') from exc
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    if isinstance(value, int):
        require(abs(value) <= MAX_SAFE, 'Unsafe integer counter')
        return str(value)
    if isinstance(value, float):
        return number_json(value)
    if isinstance(value, list):
        return '[' + ','.join(canonicalize(v, depth + 1) for v in value) + ']'
    if isinstance(value, dict):
        require(all(isinstance(k, str) for k in value), 'JSON object keys must be strings')
        # RFC 8785 orders property names by UTF-16 code units, not Unicode scalars.
        keys = sorted(value, key=lambda k: k.encode('utf-16-be', 'strict'))
        return '{' + ','.join(canonicalize(k, depth + 1) + ':' + canonicalize(value[k], depth + 1) for k in keys) + '}'
    raise Invalid('Value is not JSON')

def digest(value):
    return hashlib.sha256(canonicalize(value).encode('utf-8')).hexdigest()

def parse_json(raw, limit=20 * 1024 * 1024):
    if isinstance(raw, str):
        raw = raw.encode('utf-8', 'strict')
    require(len(raw) <= limit, 'JSON exceeds byte limit')
    try:
        text = raw.decode('utf-8', 'strict')
        def invalid_constant(value):
            raise Invalid('Nonfinite JSON number: ' + value)
        value = json.loads(text, object_pairs_hook=json_pairs, parse_constant=invalid_constant)
        canonicalize(value)
        return value
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise Invalid('Invalid UTF-8 JSON: ' + str(exc)) from exc

def read_json(path, limit):
    require(path.is_file(), 'Missing JSON file: ' + str(path))
    require(path.stat().st_size <= limit, 'JSON file exceeds byte limit')
    with path.open('rb') as handle:
        return parse_json(handle.read(limit + 1), limit)

LIMITS = read_json(REFERENCES / 'limits.json', 1024 * 1024)
CURRENCIES = read_json(REFERENCES / 'currencies.json', 1024 * 1024)
MAX_JSON = LIMITS['maxLegacyResultBytes']
SCHEMAS = {
    'v3-batch': read_json(REFERENCES / 'v3/valuation-batch.schema.json', LIMITS['maxBackupJsonBytes']),
    'v3-results': read_json(REFERENCES / 'v3/valuation-results.schema.json', LIMITS['maxBackupJsonBytes']),
    'v2-batch': read_json(REFERENCES / 'v2/valuation-batch.schema.json', LIMITS['maxBackupJsonBytes']),
    'v2-results': read_json(REFERENCES / 'v2/valuation-results.schema.json', LIMITS['maxBackupJsonBytes']),
    'v1-batch': read_json(REFERENCES / 'v1/valuation-batch.schema.json', LIMITS['maxBackupJsonBytes']),
    'v1-results': read_json(REFERENCES / 'v1/valuation-results.schema.json', LIMITS['maxBackupJsonBytes']),
}

def valid_date(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        return False
    # RFC 3339 uses four-digit proleptic Gregorian years; Python datetime's
    # year>=1 restriction must not create a different contract from the app.
    year, month, day = map(int, value.split('-'))
    if not 1 <= month <= 12:
        return False
    leap = year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
    days = [31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return 1 <= day <= days[month - 1]

def valid_timestamp(value):
    if not isinstance(value, str):
        return False
    match = re.fullmatch(r'(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-](?:0\d|1\d|2[0-3]):[0-5]\d)', value)
    return bool(match and valid_date(match[1]) and int(match[2]) < 24 and int(match[3]) < 60 and int(match[4]) < 60)

def valid_url(value):
    try:
        url = urlsplit(value)
        _ = url.port
        return url.scheme in ('http', 'https') and bool(url.hostname) and not re.search(r'\s', value)
    except ValueError:
        return False

def validate_schema(value, schema, root=None, path='/'):
    root = root or schema
    def fail(message):
        raise Invalid(path + ': ' + message)
    if '$ref' in schema:
        reference = schema['$ref']
        require(reference.startswith('#/definitions/'), 'External schema references are prohibited')
        name = reference[len('#/definitions/'):]
        require(name in root.get('definitions', {}), 'Unknown installed schema reference')
        return validate_schema(value, root['definitions'][name], root, path)
    if 'const' in schema and canonicalize(value) != canonicalize(schema['const']):
        fail('unexpected constant')
    if 'enum' in schema and not any(canonicalize(value) == canonicalize(v) for v in schema['enum']):
        fail('unsupported value')
    if 'anyOf' in schema:
        accepted = False
        for option in schema['anyOf']:
            try:
                validate_schema(value, option, root, path)
                accepted = True
                break
            except Invalid:
                pass
        if not accepted:
            fail('does not match an allowed type')
    types = {'null': value is None, 'string': isinstance(value, str), 'boolean': isinstance(value, bool), 'integer': isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and float(value).is_integer() and abs(value) <= MAX_SAFE, 'number': isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value), 'object': isinstance(value, dict), 'array': isinstance(value, list)}
    if 'type' in schema and not types.get(schema['type'], False):
        fail('expected ' + schema['type'])
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if 'minimum' in schema and value < schema['minimum']:
            fail('below minimum')
        if 'maximum' in schema and value > schema['maximum']:
            fail('above maximum')
    if isinstance(value, str):
        if len(value) < schema.get('minLength', 0) or len(value) > schema.get('maxLength', MAX_SAFE):
            fail('text length outside limits')
        if 'pattern' in schema and not re.search(schema['pattern'], value):
            fail('invalid text format')
        fmt = schema.get('format')
        if fmt == 'date' and not valid_date(value):
            fail('invalid calendar date')
        if fmt == 'date-time' and not valid_timestamp(value):
            fail('invalid timestamp')
        if fmt == 'uri' and not valid_url(value):
            fail('invalid HTTP(S) URL')
    if isinstance(value, list):
        if len(value) < schema.get('minItems', 0) or len(value) > schema.get('maxItems', MAX_SAFE):
            fail('array length outside limits')
        if schema.get('uniqueItems') and len(set(canonicalize(v) for v in value)) != len(value):
            fail('duplicate array entries')
        if 'items' in schema:
            for index, child in enumerate(value):
                validate_schema(child, schema['items'], root, path.rstrip('/') + '/' + str(index))
    if isinstance(value, dict):
        for key in schema.get('required', []):
            if key not in value:
                fail('missing ' + key)
        if len(value) > schema.get('maxProperties', MAX_SAFE):
            fail('too many properties')
        for key, child in value.items():
            if key in schema.get('properties', {}):
                validate_schema(child, schema['properties'][key], root, path.rstrip('/') + '/' + key)
            else:
                matches = [rule for pattern, rule in schema.get('patternProperties', {}).items() if re.search(pattern, key)]
                for rule in matches:
                    validate_schema(child, rule, root, path.rstrip('/') + '/' + key)
                if not matches and schema.get('additionalProperties') is False:
                    fail('unexpected property ' + key)
    for clause in schema.get('allOf', []):
        validate_schema(value, clause, root, path)
    if 'if' in schema:
        try:
            validate_schema(value, schema['if'], root, path)
            matches = True
        except Invalid:
            matches = False
        rule = schema.get('then' if matches else 'else')
        if rule:
            validate_schema(value, rule, root, path)

def unique(values, label):
    require(len(values) == len(set(values)), 'Duplicate ' + label)

def safe_path(path):
    require(isinstance(path, str) and path and not path.startswith('/') and '\\' not in path and not re.search(r'[:\x00-\x1f]', path), 'Unsafe archive path')
    require(all(part not in ('', '.', '..') for part in path.split('/')), 'Unsafe archive path')
    return path

def validate_batch(batch):
    version = batch.get('protocolVersion')
    if version in (2, 3):
        validate_schema(batch, SCHEMAS[f'v{version}-batch'])
        if version == 3:
            validate_research_context(batch['researchContext'], [item['itemId'] for item in batch['items']])
        unique([i['itemId'] for i in batch['items']], 'batch item IDs')
        unique([i['id'] for i in batch['items']], 'source snapshot IDs')
        image_ids, paths = [], []
        for item in batch['items']:
            facts = {k: v for k, v in item['facts'].items() if k != 'privateFields'}
            photos = sorted([{'id': p['id'], 'sha256': p['originalSha256'], 'annotation': p['annotation']} for p in item['images']], key=lambda p: p['id'].encode('utf-16-be'))
            subject = digest({'kind': 'cabinet-subject-v2', 'facts': facts, 'photos': photos})
            require(subject == item['subjectHash'], 'Subject hash does not match frozen evidence')
            require(digest({'kind': 'cabinet-lot-v2', 'subjectHash': subject, 'quantity': item['quantity']}) == item['lotHash'], 'Lot hash mismatch')
            require(digest({k: v for k, v in item.items() if k != 'sourceSnapshotHash'}) == item['sourceSnapshotHash'], 'Source snapshot hash mismatch')
            for image in item['images']:
                require(image['itemId'] == item['itemId'], 'Evidence ownership mismatch')
                safe_path(image['path'])
                if image['profile'] == 'originals':
                    require(image['assetId'] == image['originalAssetId'] and image['sha256'] == image['originalSha256'] and image['bytes'] == image['originalBytes'] and image['transform'] is None, 'Original image descriptor mismatch')
                else:
                    require(bool(image['transform']), 'Research copy needs a transformation record')
                image_ids.append(image['id'])
                paths.append(image['path'])
        unique(image_ids, 'photo attachment IDs')
        unique(paths, 'evidence paths')
        require(digest({k: v for k, v in batch.items() if k != 'batchManifestHash'}) == batch['batchManifestHash'], 'Batch manifest hash mismatch')
    elif batch.get('schemaVersion') == 1:
        validate_schema(batch, SCHEMAS['v1-batch'])
        unique([i['id'] for i in batch['items']], 'legacy batch items')
        image_ids, paths = [], []
        for item in batch['items']:
            require(len(item['photos']) == len(item['photoIds']), 'Legacy photo metadata is incomplete')
            for image in item['photos']:
                require(image['itemId'] == item['id'] and image['id'] in item['photoIds'], 'Legacy evidence ownership mismatch')
                safe_path(image['path'])
                image_ids.append(image['id'])
                paths.append(image['path'])
        unique(image_ids, 'legacy photo IDs')
        unique(paths, 'legacy photo paths')
    else:
        raise Invalid('Unsupported Cabinet valuation protocol version')
    return batch

def image_descriptors(batch):
    return [image for item in batch['items'] for image in item.get('images', item.get('photos', []))]

def permitted_support_files():
    # This is a fixed installed allowlist; imported archive schemas are never loaded.
    base = {'batch.json', 'response-template.json', 'valuation.schema.json', 'batch.schema.json', 'response-template.schema.json', 'protocol-limits.json', 'SKILL.md', 'README.md', 'scripts/validate_results.py'}
    base.update('references/' + str(path.relative_to(REFERENCES)).replace('\\', '/') for path in REFERENCES.rglob('*') if path.is_file())
    return base

def read_zip_batch(path):
    require(path.stat().st_size <= LIMITS['maxArchiveBytes'], 'ZIP archive exceeds compressed byte limit')
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        require(len(entries) <= LIMITS['maxArchiveEntries'], 'ZIP has too many members')
        names = [entry.filename for entry in entries]
        unique(names, 'ZIP paths')
        require('batch.json' in names, 'ZIP has no batch.json')
        total = 0
        for entry in entries:
            safe_path(entry.filename)
            require(not entry.is_dir(), 'Unexpected directory ZIP member')
            require(entry.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED) and not entry.flag_bits & 1, 'Unsupported ZIP compression or encryption')
            require(entry.file_size >= 0 and entry.compress_size >= 0, 'Invalid ZIP size')
            total += entry.file_size
        require(total <= LIMITS['maxExpandedBytes'], 'ZIP exceeds total expanded byte limit')
        info = archive.getinfo('batch.json')
        require(info.file_size <= LIMITS['maxBatchManifestBytes'], 'Batch manifest exceeds byte limit')
        with archive.open(info) as handle:
            batch = validate_batch(parse_json(handle.read(LIMITS['maxBatchManifestBytes'] + 1), LIMITS['maxBatchManifestBytes']))
        images = {image['path']: image for image in image_descriptors(batch)}
        require(set(images) <= set(names), 'A declared image is missing')
        require(set(names) <= permitted_support_files() | set(images), 'ZIP contains an unexpected file')
        actual_total = 0
        for entry in entries:
            declared = images.get(entry.filename)
            if declared:
                require(entry.file_size == declared['bytes'], 'Declared image byte count mismatch')
            actual = 0
            hasher = hashlib.sha256()
            with archive.open(entry) as handle:
                while True:
                    chunk = handle.read(65536)
                    if not chunk:
                        break
                    actual += len(chunk)
                    actual_total += len(chunk)
                    require(actual <= entry.file_size and actual_total <= LIMITS['maxExpandedBytes'], 'ZIP expanded byte limit or declared size exceeded')
                    hasher.update(chunk)
            require(actual == entry.file_size, 'ZIP actual member size mismatch')
            if declared:
                require(hasher.hexdigest() == declared['sha256'], 'Image SHA-256 mismatch: ' + entry.filename)
        return batch

def load_batch(path):
    path = Path(path)
    require(path.exists(), 'Batch path does not exist')
    if path.is_file() and zipfile.is_zipfile(path):
        return read_zip_batch(path)
    manifest_path = path / 'batch.json' if path.is_dir() else path
    batch = validate_batch(read_json(manifest_path, LIMITS['maxBatchManifestBytes']))
    root = manifest_path.parent.resolve()
    total = manifest_path.stat().st_size
    for image in image_descriptors(batch):
        member = (root / safe_path(image['path'])).resolve()
        require(member.is_relative_to(root), 'Image path escapes the batch directory')
        require(member.is_file() and member.stat().st_size == image['bytes'], 'Image is missing or has the wrong byte count')
        total += member.stat().st_size
        require(total <= LIMITS['maxExpandedBytes'], 'Batch directory exceeds aggregate byte limit')
        hasher = hashlib.sha256()
        with member.open('rb') as handle:
            for chunk in iter(lambda: handle.read(65536), b''):
                hasher.update(chunk)
        require(hasher.hexdigest() == image['sha256'], 'Image SHA-256 mismatch: ' + image['path'])
    return batch

def amount(value, fraction=6, positive=False):
    require(isinstance(value, str) and re.fullmatch(r'(0|[1-9][0-9]*)(\.[0-9]{1,' + str(fraction) + r'})?', value), 'Money must be a nonnegative decimal string')
    result = Decimal(value)
    require(result <= Decimal(LIMITS['maxAmount']) and (not positive or result > 0), 'Amount outside supported range')
    return result

def validate_result_semantics(result):
    value = result['valuation']
    if value:
        low, estimate, high = (amount(value[key]) for key in ('low', 'estimate', 'high'))
        require(low <= estimate <= high, 'Require low <= estimate <= high')
        require(value['basis'] != 'per-unit' or value['basisQuantity'] == 1, 'Per-unit basisQuantity must be 1')
        require(value['rationale'].strip(), 'Valuation requires a methodology')
    if result['status'] == 'valued':
        require(value and any(c['sourceType'] in ('sold', 'asking') and c['price'] is not None for c in result['comparables']), 'Valued requires priced sold or asking evidence')
    if result['status'] == 'unidentified':
        require(value is None and (result['identification']['notes'].strip() or any(w.strip() for w in result['warnings'])), 'Unidentified requires a null valuation and research reason')
    for comparable in result['comparables']:
        if comparable['price'] is not None:
            amount(comparable['price'])
        require(comparable['sourceType'] == 'sold' or comparable['soldAt'] is None, 'Only sold evidence may declare a sale date')
        require(comparable['priceBasis'] != 'per-unit' or comparable['quantity'] == 1, 'Per-unit comparable requires quantity 1')
        require(comparable['priceBasis'] != 'entire-lot' or comparable['quantity'] is not None, 'Lot comparable requires a quantity')
        fx = comparable['conversion']
        if fx:
            rate = amount(fx['rate'], 12, True)
            converted = amount(fx['convertedAmount'])
            require(comparable['price'] is not None and fx['fromCurrency'] == comparable['currency'] and fx['toCurrency'] != fx['fromCurrency'], 'FX must preserve a priced source currency')
            require(not value or fx['toCurrency'] == value['currency'], 'FX target must match estimate currency')
            with localcontext() as context:
                context.prec = 80
                expected = (Decimal(comparable['price']) * rate).quantize(Decimal('0.000001'), rounding=ROUND_HALF_UP)
            require(expected == converted, 'FX arithmetic mismatch: round source price times rate half-up to six decimals')
    require(result['supersedesResultId'] != result['resultId'], 'A result cannot supersede itself')

def evidence_text(value, maximum, nonempty=False):
    require(isinstance(value, str) and len(value.encode('utf-16-le')) // 2 <= maximum and (not nonempty or bool(value.strip())) and not re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', value), 'Missing or invalid evidence text')

def source_key(raw):
    evidence_text(raw, 4000, True)
    require(valid_url(raw) and not re.search(r'[\s\\]', raw), 'Citation requires an ordinary HTTP(S) URL')
    url = urlsplit(raw)
    require(url.username is None and url.password is None, 'Citation URL cannot contain credentials')
    host = unicodedata.normalize('NFKC', unquote(url.hostname)).lower().replace('\u3002', '.').replace('\uff0e', '.').replace('\uff61', '.')
    # Non-transitional Unicode DNS names preserve sharp-s, like browser URL parsing.
    host = '.'.join(label if label.isascii() else 'xn--' + label.encode('punycode').decode('ascii') for label in host.split('.'))
    if ':' in host:
        host = '[' + ipaddress.IPv6Address(host).compressed + ']'
    port = url.port
    authority = host + (':' + str(port) if port is not None and (url.scheme, port) not in [('http', 80), ('https', 443)] else '')
    # WHATWG URL path normalization: remove literal and percent-encoded dot segments.
    parts = []
    raw_path = url.path or '/'
    for index, part in enumerate(raw_path.split('/')):
        decoded = re.sub(r'%2e', '.', part, flags=re.I)
        if decoded == '.':
            if index == len(raw_path.split('/')) - 1: parts.append('')
        elif decoded == '..':
            if len(parts) > 1: parts.pop()
            if index == len(raw_path.split('/')) - 1: parts.append('')
        else:
            parts.append(part)
    path = quote('/'.join(parts), safe="/:@!$&'()*+,;=-._~%[]|^") or '/'
    query = quote(url.query, safe='!$&()*+,-./:;=?@_~%[]\\^`{|}')
    pairs = parse_qsl(query, keep_blank_values=True)
    retained = [(key, value) for key, value in pairs if not key.lower().startswith('utm_') and key.lower() not in ('fbclid', 'gclid', 'msclkid')]
    if retained != pairs:
        query = urlencode(retained, doseq=True, safe='*').replace('~', '%7E')
    empty_query = not query and retained == pairs and '?' in raw.split('#', 1)[0]
    return url.scheme.lower() + '://' + authority + path + ('?' + query if query or empty_query else '')

def normalized_market(value):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', value or '').strip()).lower()

def market_fields(scope):
    return [] if scope == 'world' else ['municipality', 'region', 'country'] if scope == 'municipality' else ['region', 'country'] if scope == 'region' else [scope]

def validate_research_context(context, item_ids):
    validate_schema(context, {'$ref': '#/definitions/research-context'}, SCHEMAS['v3-batch'])
    criteria = context['criteria']
    require(criteria['asOf'] is not None, 'Frozen criteria require an as-of date')
    require(criteria['includeSold'] or criteria['includeAsking'], 'Enable sold or asking evidence')
    for value in criteria['market'].values():
        if value is not None: evidence_text(value, 200, True)
    require(all(normalized_market(criteria['market'][field]) for field in market_fields(criteria['scope'])), 'Choose a reference market before gathering evidence')
    seen = set()
    for row in context['sourceFeedback']:
        key = (row['itemId'], row['sourceKey'])
        require(row['itemId'] in item_ids and key not in seen, 'Feedback belongs to another item or repeats a URL')
        require(row['sourceKey'] == source_key(row['sourceUrl']), 'Feedback key does not match its citation')
        evidence_text(row['reason'], 2000)
        require(row['decision'] != 'denied' or row['reasonCode'] is not None and (row['reasonCode'] != 'other' or bool(row['reason'].strip())), 'Denial requires a reason; Other also needs an explanation')
        seen.add(key)
    return context

def validate_comparable_evidence(source):
    source_key(source['url'])
    for field in ('citation', 'locationEvidence', 'authenticityEvidence'):
        evidence_text(source[field], 2000, True)
    for value in source['market'].values():
        if value is not None: evidence_text(value, 200, True)
    if source['size'] is not None: evidence_text(source['size'], 200, True)
    for field in ('publishedAt', 'listedAt', 'soldAt'):
        value = source[field]
        require(value is None or valid_date(value) and value <= source['accessedAt'][:10], 'Source event date cannot follow its recorded access date')
    require(source['sourceType'] != 'sold' or source['listedAt'] is None or source['soldAt'] is None or source['listedAt'] <= source['soldAt'], 'Listing cannot start after the sale date')

def calendar_day(value):
    # Proleptic Gregorian arithmetic also admits year 0000, as the app does.
    year, month, day = map(int, value.split('-'))
    prior = year - 1
    leap = year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
    months = [31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return prior * 365 + prior // 4 - prior // 100 + prior // 400 + sum(months[:month - 1]) + day

def fraction_amount(value):
    numerator = (value.numerator * 1000000 * 2 + value.denominator) // (value.denominator * 2)
    text = str(numerator).zfill(7)
    return (text[:-6] + '.' + text[-6:]).rstrip('0').rstrip('.')

def estimate_evidence(comparables, criteria, item_id, currency, basis, basis_quantity, feedback=None):
    """Return exact reproducible evidence values; no source price is invented or adjusted."""
    validate_research_context({'criteria': criteria, 'sourceFeedback': feedback or []}, [item_id])
    reviews = {row['sourceKey']: row for row in feedback or [] if row['itemId'] == item_id}
    included = []
    for source in comparables:
        validate_comparable_evidence(source)
        key = source_key(source['url'])
        review = reviews.get(key)
        if review and review['decision'] == 'denied' or criteria['approvedOnly'] and (not review or review['decision'] != 'approved'):
            continue
        if source['access'] != 'observed' or source['sourceType'] == 'reference' or source['price'] is None or source['itemMatch'] != 'exact' or source['conditionMatch'] != 'same':
            continue
        if not all(normalized_market(source['market'][field]) and normalized_market(source['market'][field]) == normalized_market(criteria['market'][field]) for field in market_fields(criteria['scope'])):
            continue
        if source['sourceType'] == 'sold' and not criteria['includeSold'] or source['sourceType'] == 'asking' and not criteria['includeAsking']:
            continue
        event_date = source['soldAt'] if source['sourceType'] == 'sold' else source['listedAt']
        if event_date is None: continue
        age = calendar_day(criteria['asOf']) - calendar_day(event_date)
        if not 0 <= age <= criteria['windowDays'] or source['priceBasis'] != basis or source['quantity'] != basis_quantity:
            continue
        fx = source['conversion']
        if source['currency'] != currency and (not fx or fx['toCurrency'] != currency): continue
        price = source['price'] if source['currency'] == currency else fx['convertedAmount']
        amount(price)
        included.append((source, Fraction(price), Fraction(criteria['windowDays'], criteria['windowDays'] + age)))
    sold = [row for row in included if row[0]['sourceType'] == 'sold']
    if sold: included = sold
    seen, unique_sources = set(), []
    for row in included:
        key = source_key(row[0]['url'])
        if key not in seen:
            seen.add(key)
            unique_sources.append(row)
    included = unique_sources
    if not included: return None
    weighted = sum((price * weight for _, price, weight in included), Fraction()) / sum((weight for _, _, weight in included), Fraction())
    low, high = min(price for _, price, _ in included), max(price for _, price, _ in included)
    estimate = fraction_amount(weighted)
    return {'estimate': estimate, 'low': fraction_amount(low), 'high': fraction_amount(high), 'lowerError': fraction_amount(Fraction(estimate) - low), 'upperError': fraction_amount(high - Fraction(estimate)), 'fraction': {'numerator': str(weighted.numerator), 'denominator': str(weighted.denominator)}, 'sourceIds': [row[0]['sourceId'] for row in included], 'status': 'sold' if sold else 'asking-only'}

def validate_pricing_evidence(result, context):
    for source in result['comparables']: validate_comparable_evidence(source)
    unique([source['sourceId'] for source in result['comparables']], 'source evidence IDs')
    value, pricing = result['valuation'], result['pricing']
    if value is None:
        require(pricing is None, 'Null valuation requires null pricing evidence')
        return
    require(pricing is not None, 'A protocol3 estimate requires reproducible pricing evidence')
    feedback = [row for row in context['sourceFeedback'] if row['itemId'] == result['itemId']]
    require(pricing['criteria'] == context['criteria'] and pricing['sourceFeedback'] == feedback, 'Pricing criteria or feedback differ from the frozen gathering')
    derived = estimate_evidence(result['comparables'], pricing['criteria'], result['itemId'], value['currency'], value['basis'], value['basisQuantity'], feedback)
    require(derived is not None, 'No eligible evidence supports the estimate')
    for field in ('low', 'estimate', 'high'):
        require(amount(value[field]) == amount(derived[field]), 'Reported ' + field + ' differs from the evidence calculation')
    expected = {'method': 'recency-weighted-mean-v1', 'criteria': context['criteria'], 'sourceFeedback': feedback, **{field: derived[field] for field in ('fraction', 'sourceIds', 'lowerError', 'upperError')}}
    require(pricing == expected, 'Pricing fraction, source IDs, or asymmetric errors do not match the calculation')
    require(value['asOf'] == pricing['criteria']['asOf'], 'Estimate date must equal frozen criteria date')
    require(result['status'] != 'valued' or derived['status'] == 'sold', 'Asking-only evidence must remain provisional needs-review')

def validate_results(payload, batch):
    require(payload.get('kind') != 'cabinet-valuation-template', 'A response template is not a result envelope')
    for key in ('collectionId', 'exportId', 'batchId'):
        require(payload.get(key) == batch.get(key), 'Return ' + key + ' does not match the recorded batch')
    if batch.get('protocolVersion') in (2, 3):
        validate_schema(payload, SCHEMAS[f"v{batch['protocolVersion']}-results"])
        require(payload['batchManifestHash'] == batch['batchManifestHash'], 'Return batch manifest hash mismatch')
        by_id = {i['itemId']: i for i in batch['items']}
        ids = [r['itemId'] for r in payload['results']] + [d['itemId'] for d in payload['deferred']]
        unique(ids, 'result/deferred item IDs')
        unique([r['resultId'] for r in payload['results']], 'result IDs')
        require(bool(ids) and set(ids) <= set(by_id), 'Empty return or unknown batch membership')
        require(payload['completion'] != 'complete' or set(ids) == set(by_id), 'Complete return must account for every batch item')
        by_result = {r['resultId']: r for r in payload['results']}
        for result in payload['results']:
            source = by_id[result['itemId']]
            require(result['sourceSnapshotHash'] == source['sourceSnapshotHash'], 'Return source snapshot hash mismatch')
            validate_result_semantics(result)
            if batch['protocolVersion'] == 3:
                validate_pricing_evidence(result, batch['researchContext'])
            value = result['valuation']
            if value:
                require(value['currency'] == batch['currency'], 'Estimate currency must match requested currency')
                require(value['basis'] != 'entire-lot' or value['basisQuantity'] == source['quantity'], 'Lot basisQuantity must equal frozen source quantity')
            seen = {result['resultId']}
            link = result['supersedesResultId']
            while link in by_result:
                require(link not in seen, 'Cyclic supersession')
                previous = by_result[link]
                require(previous['itemId'] == result['itemId'], 'Supersession must remain within the same item')
                seen.add(link)
                link = previous['supersedesResultId']
    else:
        validate_schema(payload, SCHEMAS['v1-results'])
        by_id = {i['id']: i for i in batch['items']}
        unique([r['itemId'] for r in payload['results']], 'legacy result item IDs')
        for result in payload['results']:
            require(result['itemId'] in by_id and result['sourceRevision'] == by_id[result['itemId']]['revision'], 'Legacy item or source revision mismatch')
            value = result['valuation']
            if value:
                require(value['currency'] == batch['currency'], 'Legacy estimate currency mismatch')
                require(value['low'] <= value['estimate'] <= value['high'], 'Require low <= estimate <= high')
    return payload

def clock_warnings(payload, now=None):
    if payload.get('protocolVersion') not in (2, 3):
        return []
    cutoff = (now or dt.datetime.now(dt.timezone.utc)) + dt.timedelta(hours=24)
    dates = [payload['generatedAt']]
    for result in payload['results']:
        if result['valuation']:
            dates.append(result['valuation']['asOf'])
        for comparable in result['comparables']:
            dates.extend([comparable['accessedAt'], comparable['soldAt']])
            if payload['protocolVersion'] == 3:
                dates.extend([comparable['listedAt'], comparable['publishedAt']])
            if comparable['conversion']:
                dates.append(comparable['conversion']['asOf'])
    for value in filter(None, dates):
        if value.startswith('0000-'):
            continue  # Valid proleptic date; it cannot exceed today's future cutoff.
        instant = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
        if instant.tzinfo is None:
            instant = instant.replace(tzinfo=dt.timezone.utc)
        if instant > cutoff:
            return ['A supplied date is more than 24 hours in the future; collector acknowledgement will be required.']
    return []

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('paths', nargs='*')
    parser.add_argument('--batch')
    parser.add_argument('--results')
    parser.add_argument('--canonical-json', help='Print the canonical bytes and SHA-256 of a bounded JSON file')
    args = parser.parse_args(argv)
    if args.canonical_json:
        value = read_json(Path(args.canonical_json), MAX_JSON)
        print(json.dumps({'canonical': canonicalize(value), 'sha256': digest(value)}, ensure_ascii=False))
        return 0
    batch_path = args.batch or (args.paths[0] if args.paths else None)
    results_path = args.results or (args.paths[1] if len(args.paths) > 1 else None)
    require(batch_path, 'Provide --batch batch.zip or batch.json')
    batch = load_batch(batch_path)
    if results_path:
        payload = read_json(Path(results_path), LIMITS['maxResultBytes'])
        validate_results(payload, batch)
        for warning in clock_warnings(payload):
            print('REVIEW: ' + warning, file=sys.stderr)
        print(f"Valid Cabinet results: {len(payload['results'])} completed findings; source images verified. Findings still require collector review.")
    else:
        print(f"Valid Cabinet batch: {len(batch['items'])} records; {len(image_descriptors(batch))} delivered images verified.")
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (Invalid, OSError, zipfile.BadZipFile, ValueError, KeyError, TypeError, UnicodeError) as exc:
        print('INVALID: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
