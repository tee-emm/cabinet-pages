# Evidence calculation for protocol 3

Use this reference after gathering and recording the actual source observations. The installed validator exports the same deterministic calculation used by Cabinet. It does not browse, judge authenticity, or establish that a source observation is truthful.

## Admission order

1. Keep the manifest's research criteria and that item's source feedback unchanged. Use the frozen `asOf` date. Geography uses normalized exact strings, never inferred coordinates or exchange-rate currency. Municipality compares municipality, region and country; region compares region and country; country/continent compare that named field; world accepts unknown geography if the source honestly records it.
2. Exclude denied canonical URLs. `approvedOnly` additionally requires an approved decision. URL matching removes fragment and common tracking parameters (`utm_*`, `fbclid`, `gclid`, `msclkid`); retain parameters identifying the actual listing.
3. Require `access: "observed"`, `itemMatch: "exact"`, `conditionMatch: "same"`, a non-null observed price, and source type sold or asking. Identification references remain visible but do not enter the estimate.
4. Use `soldAt` for sales and `listedAt` for asking listings. Dates must be known and between `asOf - windowDays` and `asOf`, inclusive. Preserve an unknown date as null. Published/access dates cannot substitute for unknown sale/listing dates.
5. Require the same price basis and quantity as the estimate. Per-unit requires quantity 1. Entire-lot requires the frozen item quantity. Do not divide a bundle into invented independent unit prices.
6. Require the requested currency or an explicitly sourced conversion. Preserve the original price. Compute `convertedAmount = original * rate` exactly, rounding half-up to six fractional places.
7. If any eligible sold observations remain, calculate from those and retain asking observations only as context. Otherwise calculate from eligible asking observations and use a provisional `needs-review` result. If none remain, return null valuation and null pricing.
8. Within the selected sold or asking pool, count each canonical URL once: the first eligible occurrence in comparable order. A completed sale takes precedence over an asking observation of that same page. Include at most 50 comparables overall and keep source IDs unique within the result.

## Exact rational arithmetic

For each included source, let `d` be the number of whole calendar days between its market event and the criteria date, and `W = windowDays`.

```text
weight = W / (W + d)
fraction = sum(price * weight) / sum(weight)
estimate = fraction rounded half-up to 6 decimal places
low = minimum included source price
high = maximum included source price
lowerError = estimate - low
upperError = high - estimate
```

Reduce `fraction` to numerator and denominator integer strings. Use `Fraction` or integer arithmetic, never binary floating point. Amounts remain nonnegative decimal strings. Remove unnecessary trailing decimal zeros from computed fields. Do not round source amounts before calculating, except the prescribed six-place FX conversion.

For example, two eligible sales at `"100"` (age 0) and `"162.19"` (age 90) with a 90-day window have weights 1 and 1/2. Their reduced central fraction is `12073/100`; the estimate is `"120.73"`, low `"100"`, high `"162.19"`, lower error `"20.73"`, and upper error `"41.46"`. These are synthetic arithmetic inputs, not real market evidence.

The low/high range is an observed evidence envelope, not a statistical confidence interval. One source produces equal endpoints and still leaves uncertainty. Report sparse evidence and known differences in the rationale rather than changing the exact formula.

## Use the installed calculation helper

Load `scripts/validate_results.py` from this installed skill using Python `importlib.util`, then call:

```python
derived = validator.estimate_evidence(
    result["comparables"],
    batch["researchContext"]["criteria"],
    result["itemId"],
    batch["currency"],
    "per-unit",  # or entire-lot, according to actual evidence
    1,           # or the frozen lot quantity
    [row for row in batch["researchContext"]["sourceFeedback"]
     if row["itemId"] == result["itemId"]],
)
```

The return is `None` or a dictionary with exact `estimate`, `low`, `high`, `lowerError`, `upperError`, `fraction`, contributing `sourceIds`, and `status` (`sold` or `asking-only`). Copy the amount fields into the valuation, using the frozen criteria date for its `asOf`. Build `pricing` with:

```python
pricing = {
    "method": "recency-weighted-mean-v1",
    "criteria": batch["researchContext"]["criteria"],
    "sourceFeedback": [row for row in batch["researchContext"]["sourceFeedback"]
                       if row["itemId"] == result["itemId"]],
    "fraction": derived["fraction"],
    "sourceIds": derived["sourceIds"],
    "lowerError": derived["lowerError"],
    "upperError": derived["upperError"],
}
```

Choose truthful confidence and rationale separately. Eligibility of source prices does not resolve item identity or authenticate it. The helper's asking-only status always requires `needs-review`; unresolved identity, authenticity, or meaningful condition ambiguity also calls for review. Run the complete installed validator against the original batch and completed result JSON before delivering it.
